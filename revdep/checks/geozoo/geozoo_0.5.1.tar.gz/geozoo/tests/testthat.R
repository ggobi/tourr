library(testthat)
library(geozoo)

test_check("geozoo")
